package com.voxi.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ChatMessage(val text: String, val fromUser: Boolean)

private val Night = Color(0xFF070914)
private val Panel = Color(0xFF11182D)
private val Blue = Color(0xFF168BFF)
private val Purple = Color(0xFF8A2BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VoxiApp() }
    }
}

@Composable
fun VoxiApp() {
    var draft by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var messages by remember {
        mutableStateOf(listOf(
            ChatMessage("Hi! I'm Voxi, your AI assistant. How can I help you today?", false),
            ChatMessage("You can try chatting, preparing a WhatsApp message, or exploring settings.", false)
        ))
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Night, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Night).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Blue, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                    Text("V", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Voxi", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Your personal AI assistant", color = Color(0xFF9DAACB), fontSize = 12.sp)
                }
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.LightGray)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Talk. Ask. Get things done.", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("Voice input • AI chat • Message drafts", color = Color(0xFF9DAACB), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("CONVERSATION", color = Color(0xFF8F9ABD), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 6.dp)) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (message.fromUser) Color(0xFF263BC0) else Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                            Text(message.text, Modifier.padding(13.dp), color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, placeholder = { Text("Message Voxi…", color = Color.Gray) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(18.dp), singleLine = true)
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    if (draft.isNotBlank()) {
                        messages = messages + ChatMessage(draft.trim(), true) + ChatMessage("I'm a starter demo right now. Connect a secure AI backend to enable real AI replies.", false)
                        draft = ""
                    }
                }, modifier = Modifier.size(48.dp).background(Brush.linearGradient(listOf(Blue, Purple)), CircleShape)) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                NavItem(Icons.Default.Home, "Home")
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(onClick = { listening = !listening }) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice input placeholder", tint = if (listening) Purple else Blue, modifier = Modifier.size(30.dp))
                    }
                    Text(if (listening) "Voice demo" else "Voice", color = Color(0xFFB8C5E6), fontSize = 11.sp)
                }
                NavItem(Icons.Default.History, "History")
                NavItem(Icons.Default.Settings, "Settings")
            }
            Text("Starter concept • voice and AI services not connected", color = Color(0xFF687593), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = Color(0xFF91A4D2), modifier = Modifier.size(23.dp))
        Text(label, color = Color(0xFF91A4D2), fontSize = 11.sp)
    }
}
