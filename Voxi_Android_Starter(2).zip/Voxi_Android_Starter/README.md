# Voxi Android Starter

This is a **starter Android Studio project** for the Voxi personal assistant concept. It includes a Jetpack Compose chat-style UI, a voice-input button placeholder, sample assistant messages, a WhatsApp-message preparation example, and the generated visual concept image.

## Important limitations
- This is source code, not an installable APK.
- AI replies are demo text. To enable real AI conversation, add a backend service and securely store API credentials on the server. Do not embed secret API keys in the Android app.
- The microphone button is a UI placeholder; speech recognition and a reliable always-listening “Hi Voxi” wake word are not implemented.
- WhatsApp message sending is not automated. A production version should open WhatsApp with a prepared draft and require the user to confirm sending.
- Phone controls are limited by Android permissions and platform restrictions.

## Build requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK 35

## Build on a computer
1. Extract this ZIP.
2. Open the `Voxi_Android_Starter` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run the app on an Android emulator or connected phone.

## Using only your Samsung Galaxy A24
You can download and extract the ZIP in **My Files**, and view/edit source files with a code editor, but building an APK from a full Android Studio project is generally easiest on a computer or a cloud development environment. This ZIP does not contain an APK.
